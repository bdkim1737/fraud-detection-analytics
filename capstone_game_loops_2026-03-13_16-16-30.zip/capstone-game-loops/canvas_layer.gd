extends CanvasLayer

const MAIN_MENU_SCENE = "res://scenes/MainMenu.tscn"
const BASE_SCENE = "res://scenes/Base.tscn"

func _ready():
	hide()

func _input(event):
	if event.is_action_pressed("ui_cancel"):
		toggle_pause()

func toggle_pause():
	get_tree().paused = !get_tree().paused
	visible = get_tree().paused

func _on_resume_button_pressed():
	get_tree().paused = false
	hide()

func _on_return_base_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file(BASE_SCENE)

func _on_main_menu_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file(MAIN_MENU_SCENE)
